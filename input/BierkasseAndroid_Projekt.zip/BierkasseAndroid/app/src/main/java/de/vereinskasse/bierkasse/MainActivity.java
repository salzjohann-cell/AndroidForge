package de.vereinskasse.bierkasse;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private final String PREFS = "bierkasse";
    private JSONArray guests = new JSONArray();
    private LinearLayout list;
    private TextView totalView;
    private final NumberFormat euro = NumberFormat.getCurrencyInstance(Locale.GERMANY);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF174A35);
        getWindow().setNavigationBarColor(0xFF123A2B);
        load();
        render();
    }

    private void load() {
        try { guests = new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString("guests", "[]")); }
        catch (Exception e) { guests = new JSONArray(); }
    }
    private void save() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("guests", guests.toString()).apply();
    }
    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xFF18352A); if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(0xFFFFFFFF);
        b.setAllCaps(false); b.setTextSize(15); b.setBackground(bg(color, 14));
        b.setPadding(dp(8), dp(8), dp(8), dp(8)); return b;
    }
    private void render() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(20)); root.setBackgroundColor(0xFFF7F5EC);
        scroll.addView(root);
        TextView title = text("🍺  Bierkasse", 28, true);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView sub = text("Getränke buchen · Strichliste · Bezahlen", 14, false);
        sub.setTextColor(0xFF587065); root.addView(sub);

        Button add = button("+  Person hinzufügen", 0xFF23764F);
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(-1, dp(52));
        addLp.setMargins(0, dp(16), 0, dp(14)); root.addView(add, addLp);
        add.setOnClickListener(v -> addGuest());

        LinearLayout drinks = new LinearLayout(this); drinks.setOrientation(LinearLayout.HORIZONTAL);
        Button beer = button("🍺 Bier / Radler\n2,00 €", 0xFF23764F);
        Button soft = button("🥤 Limo / Wasser\n1,50 €", 0xFF286D91);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(74), 1);
        half.setMargins(0, 0, dp(6), 0); drinks.addView(beer, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(74), 1);
        half2.setMargins(dp(6), 0, 0, 0); drinks.addView(soft, half2);
        root.addView(drinks);
        TextView hint = text("1. Person auswählen, 2. Getränk antippen.", 13, false);
        hint.setTextColor(0xFF587065); hint.setPadding(0, dp(10), 0, dp(12)); root.addView(hint);

        totalView = text("", 20, true); totalView.setPadding(dp(14), dp(12), dp(14), dp(12));
        totalView.setBackground(bg(0xFFDCEEDD, 14)); root.addView(totalView);
        TextView heading = text("Offene Strichlisten", 20, true);
        heading.setPadding(0, dp(20), 0, dp(8)); root.addView(heading);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);
        beer.setOnClickListener(v -> chooseGuest(2.00));
        soft.setOnClickListener(v -> chooseGuest(1.50));
        setContentView(scroll);
        refreshList();
    }
    private void addGuest() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("Name");
        new AlertDialog.Builder(this).setTitle("Neue Person").setView(input)
            .setPositiveButton("Hinzufügen", (d,w) -> {
                String name = input.getText().toString().trim();
                if (!name.isEmpty()) {
                    try { JSONObject g = new JSONObject(); g.put("name", name); g.put("beer", 0); g.put("soft", 0); g.put("paid", false); guests.put(g); save(); refreshList(); }
                    catch (Exception ignored) {}
                }
            }).setNegativeButton("Abbrechen", null).show();
    }
    private void chooseGuest(double price) {
        if (guests.length() == 0) {
            new AlertDialog.Builder(this).setMessage("Bitte zuerst eine Person hinzufügen.")
                .setPositiveButton("Person hinzufügen", (d,w) -> addGuest()).setNegativeButton("Abbrechen", null).show();
            return;
        }
        String[] names = new String[guests.length()];
        for (int i=0;i<guests.length();i++) names[i] = guests.optJSONObject(i).optString("name");
        new AlertDialog.Builder(this).setTitle(price == 2.0 ? "Bier / Radler buchen" : "Limo / Wasser buchen")
            .setItems(names, (d, which) -> {
                JSONObject g = guests.optJSONObject(which);
                String key = price == 2.0 ? "beer" : "soft";
                try { g.put(key, g.optInt(key,0)+1); g.remove("paid"); save(); refreshList(); } catch (Exception ignored) {}
            }).show();
    }
    private double amount(JSONObject g) { return g.optInt("beer",0)*2.0 + g.optInt("soft",0)*1.5; }
    private void refreshList() {
        if (list == null) return;
        list.removeAllViews(); double total = 0;
        for (int i=0;i<guests.length();i++) {
            final int idx = i; JSONObject g = guests.optJSONObject(i);
            double due = amount(g); if (due <= 0) continue; total += due;
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10)); card.setBackground(bg(0xFFFFFFFF, 14));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.setMargins(0, dp(5), 0, dp(5)); list.addView(card, cp);
            TextView name = text(g.optString("name"), 18, true); card.addView(name);
            TextView details = text(g.optInt("beer",0)+" × Bier/Radler  ·  "+g.optInt("soft",0)+" × Limo/Wasser", 14, false);
            details.setTextColor(0xFF587065); card.addView(details);
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setOrientation(LinearLayout.HORIZONTAL);
            TextView price = text(euro.format(due), 20, true); row.addView(price, new LinearLayout.LayoutParams(0, dp(48), 1));
            Button undo = button("−", 0xFF8B5E3C); Button paid = button("Bezahlt ✓", 0xFF23764F);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, dp(44)); bp.setMargins(dp(4), 0, 0, 0);
            row.addView(undo, bp); row.addView(paid, bp); card.addView(row);
            undo.setOnClickListener(v -> decrement(idx));
            paid.setOnClickListener(v -> settle(idx));
        }
        totalView.setText("Offen gesamt:  " + euro.format(total));
        if (list.getChildCount() == 0) {
            TextView empty = text("Noch keine offenen Getränke. Füge eine Person hinzu und buche das erste Getränk.", 15, false);
            empty.setPadding(dp(12), dp(12), dp(12), dp(12)); list.addView(empty);
        }
    }
    private void decrement(int i) {
        JSONObject g = guests.optJSONObject(i); if (g == null) return;
        try { if (g.optInt("soft",0)>0) g.put("soft", g.optInt("soft")-1);
        else if (g.optInt("beer",0)>0) g.put("beer", g.optInt("beer")-1);
        save(); refreshList(); } catch (Exception ignored) {}
    }
    private void settle(int i) {
        JSONObject g = guests.optJSONObject(i); if (g == null) return;
        String name = g.optString("name"); double due = amount(g);
        new AlertDialog.Builder(this).setTitle("Zahlung bestätigen")
            .setMessage(name + " bezahlt " + euro.format(due) + "?\nDie Strichliste wird auf null gesetzt.")
            .setPositiveButton("Bezahlt", (d,w) -> {
                try { g.put("beer",0); g.put("soft",0); save(); refreshList(); } catch (Exception ignored) {}
            }).setNegativeButton("Abbrechen", null).show();
    }
}
