# Bierkasse – Android-Projekt

Enthaltene Funktionen:
- Zwei Getränkekategorien: Bier/Radler 2,00 € und Limo/Wasser 1,50 €
- Personen anlegen
- Getränk pro Person buchen
- Offene Strichliste und Gesamtbetrag
- Fehlbuchung reduzieren
- Zahlung bestätigen und Strichliste auf null setzen
- Lokale Speicherung auf dem Gerät, kein Internet erforderlich

## APK erstellen
Dieses Paket ist das vollständige Android-Studio-Projekt. Eine fertige APK konnte in der aktuellen Umgebung nicht kompiliert werden, da hier kein Android SDK/Gradle-Buildsystem installiert ist.

1. Android Studio installieren: https://developer.android.com/studio
2. Android Studio öffnen und **Open** wählen, dann den Ordner `BierkasseAndroid` auswählen.
3. Warten, bis Gradle synchronisiert ist.
4. Menü **Build → Build Bundle(s) / APK(s) → Build APK(s)** wählen.
5. Die APK liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`.

Hinweis: „Bezahlt“ setzt die Getränkezähler dieser Person auf null; die bisherige Einzelbuchungshistorie wird nicht separat archiviert.
